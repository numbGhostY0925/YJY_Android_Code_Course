package com.example.yangjianyong.myapplication;

import android.app.Activity;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.LinearLayout;
import android.widget.TextView;

public class JAVAMainActivity extends Activity {
	//步骤4:声明各种需要使用的组件和资源文件,TextView,字符串、颜色、尺寸
	//步骤4-1：声明使用的TextView组件，7个
	private TextView[]   textview=new TextView[7];
	//步骤4-2:字符串
	private   int[]   textstr=new int[]{R.string.strcolor1,R.string.strcolor2,R.string.strcolor3,
			R.string.strcolor4,R.string.strcolor5,R.string.strcolor6,R.string.strcolor7};
	//步骤4-3:颜色
	private int[]  color=new int[]{R.color.color1,R.color.color2,R.color.color3,R.color.color4,
			R.color.color5,R.color.color6,R.color.color7};
	//步骤4-4:尺寸
	private int[]  dimen=new int[]{R.dimen.dimen1,R.dimen.dimen2,R.dimen.dimen3,R.dimen.dimen4,
			R.dimen.dimen5,R.dimen.dimen6,R.dimen.dimen7};

	//步骤1:按键【Alt+/】  添加一个方法 onCreate
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		//步骤2:添加布局文件java_activity_main.xml
		setContentView(R.layout.java_activity_main);
		//步骤3:找到布局文件中的线性布局
		LinearLayout  layout=(LinearLayout) findViewById(R.id.linearlayoutjava);
		//步骤5:用循环的方式来生成组件，配置组件的文字颜色和尺寸，加载到线性布局上
		for (int i=0;i<textview.length-2;i++){
			//5-1:创建一个TextView
			textview[i]=new TextView(this);
			//5-2:居中
			textview[i].setGravity(Gravity.CENTER);
			//5-3：获得文字
			textview[i].setText(textstr[i]);
			//5-4：获得颜色
			textview[i].setBackgroundColor((int)(super.getResources().getColor(color[i])));
			//5-5：获得尺寸
			textview[i].setHeight((int)(super.getResources().getDimension(dimen[i])));
			//5-6：添加到布局中
			layout.addView(textview[i]);
		}
	}
}
