package com.example.yangjianyong.myxmljava;

import android.app.Activity;
import android.content.res.XmlResourceParser;
import android.os.Bundle;
import android.widget.TextView;
import org.xmlpull.v1.XmlPullParserException;

import java.io.IOException;
public class MainActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //步骤1：创建一个xml文件的格式解析器,获得xml文件
        XmlResourceParser xrp=getResources().getXml(R.xml.myinfo);
        //步骤2：创建一个空的字符串构建器，存在读到的数据
        StringBuilder  sb=new StringBuilder("");

        //步骤3：用循环的方式来读取xml文件 while循环
        try {
            //步骤3-1:是否到XML文档结尾，END_DOCUMENT,没有的话继续读
            while (xrp.getEventType()!=XmlResourceParser.END_DOCUMENT){
                //步骤3-2:是否为TAG的开始标记
                if (xrp.getEventType()==XmlResourceParser.START_TAG){
                    //步骤3-3是的话，获得标记名
                    String  tagName=xrp.getName();
                    //步骤3-4将获得标记名匹配用户给出的标记名
                    if (tagName.equals("myyjyinfo")){
                        //步骤3-5:匹配成功的话，读内容
                        sb.append("编号:"+xrp.getAttributeValue(0)+"   |   ");
                        sb.append("姓名:"+xrp.getAttributeValue(1)+"   |   ");
                        sb.append("性别:"+xrp.getAttributeValue(2)+"  |   ");
                        sb.append("地址:"+xrp.getAttributeValue(3)+"   ");
                        sb.append("\n");
                    }
                }
                //步骤3-6：读取下一个标记
                xrp.next();
            }
            //步骤6:获得布局文件中的TextView控件
            TextView tv=(TextView) findViewById(R.id.show);
            //步骤7：显示读取的XML文件信息
            tv.setText(sb.toString());
        } catch (XmlPullParserException e) {//步骤4:xrp.getEventType()抛出的异常
            e.printStackTrace();
        } catch (IOException e) {//步骤5：xrp.next()抛出的异常
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }
}
