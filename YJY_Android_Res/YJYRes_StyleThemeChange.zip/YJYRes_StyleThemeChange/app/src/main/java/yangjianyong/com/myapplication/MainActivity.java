package yangjianyong.com.myapplication;

import android.app.Activity;
import android.content.res.Resources;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

//预备工作是：1-将图片放入到drawable 中。
//在程序中需要使用文字等信息，先设置好，res--values--strings
//样式放在styles文件中，分别设计四种不同的样式
//dimens等分别设计好
//在layout中分别设置四种布局文件，对应春夏秋冬四种界面的显示

public class MainActivity extends Activity {
    //步骤1：声明程序中用到的各种资源文件，布局文件、图片，风格样式，按钮
    //步骤1-1：获得样式文件，分别对应春夏秋冬，下同
    private int[]  theme=new int[]{R.style.spring,R.style.summer,R.style.autumn,R.style.winner};
    //步骤1-2：获得布局文件
    private int[]  activitymain=new int[]{R.layout.activity_main,R.layout.summer_activity_main,
            R.layout.autumn_activity_main,R.layout.winner_activity_main};
    //步骤1-3：获得图片资源
    private  int[] resimage=new int[]{R.drawable.spring,R.drawable.summer,
            R.drawable.autumn,R.drawable.winter};
    //步骤1-4：每一个界面中都有一个按钮（很重要）
    private Button bntchange=null;
    //步骤1-5：
    private int i=0;
    //步骤1-6：
    private  View view=null;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        //步骤2：调用春天的样式
        super.setTheme(R.style.spring);
        super.onCreate(savedInstanceState);
        //直接在这里运行，可以出现春天的界面，但是设计好的样式并没有被调用
        //样式的调用必须在布局文件出现之前，先写步骤2
        //写完步骤2之后再运行
        setContentView(R.layout.activity_main);
        //上面的程序可以运行处结果，但是点击按钮没有反应的，这个步骤3设置按钮的点击事件

        //步骤3：找到按钮
        this.bntchange=findViewById(R.id.bntchange);
        //步骤4：编写按钮的点击事件
       /* bntchange.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
            } });*/
        //步骤4：编写按钮的点击事件,自定义，需要自己编写，写到外部
        bntchange.setOnClickListener(new OnClickListenerImpl());
    }

    //步骤5：按钮的点击事件编写
    private class OnClickListenerImpl implements View.OnClickListener{
        @Override
        public void onClick(View view) {
            //步骤6：按钮点击一下，获得下一个界面的相关信息并显示出来
            //步骤6-1：获得当前所在的界面,需要一个变量来定位，回到1-5定义一个变量
            i=i+1;
            //步骤6-7：防止数组越界的代码
            if (i==4) i=0;
            //步骤6-2：获得第i个界面的theme
            MainActivity.this.setTheme(theme[i]);
            //步骤6-3：获得第个界面的布局文件
            setContentView(activitymain[i]);
            //步骤6-4:需要使用一个视图view来加载布局文件，回到1-6定义一个view
            view=findViewById(R.id.linearlayout);
            //步骤6-5:加载背景资源
            view.setBackgroundResource(resimage[i]);
            //写完6-5之后，点击春天的按钮能够调到夏天的界面，
            // 但是在夏天的界面上的按钮是没有反应的，原因理解了吗？
            //步骤6-6：在新的界面上找到新的按钮，设置事件
            bntchange=findViewById(R.id.bntchange);
            bntchange.setOnClickListener(new OnClickListenerImpl());
            //写完6-6：程序能够运行，但是当运行到冬天之后再点击就会出现数组越界的错误
            //原因在于i不断的自增之后，超过数组长度所致，当i=4之后，必须回旋回来
            //在 步骤6-1之后，判断是否越界，越界就加代码6-7
        }
    }




}
