package yangjianyong.com.myxmljava;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.LinearLayout;


//在布局文件中生成一个线性布局,界面调用这个线性布局
//用Java代码来创建4个图片组件，放置在界面上
public class MainActivity extends Activity {
    //1-调用一个数组，放置图片组件
    private ImageView[] img=new ImageView[4];
    //2-调用一个数组资源，放置图片
    private int[] imagePath=new int[]{R.drawable.img01,R.drawable.img02,R.drawable.img03,R.drawable.img04};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //3-因为调用布局文件中生成的布局，需要id值，返回文件中定义线性布局的id
        LinearLayout layout=findViewById(R.id.layout);
        //4-用循环方式来生成四个组件，放置图片
        for (int i=0;i<imagePath.length;i++){
            //4-1:创建图片组件，用来放置图片
            img[i]=new ImageView(this);
            //4-2:将图片资源放入图片组件中
            img[i].setImageResource(imagePath[i]);
            //4-3：设置图片之间的间隔
            img[i].setPadding(5,5,5,5);
            //4-4：设置图片的尺寸
            LinearLayout.LayoutParams params=new LinearLayout.LayoutParams(160,80);
            //4-5：将设置好的尺寸，加载到图片上
            img[i].setLayoutParams(params);
            //5:在线性布局中，将图片组件放置进去
            layout.addView(img[i]);
        }
    }
}