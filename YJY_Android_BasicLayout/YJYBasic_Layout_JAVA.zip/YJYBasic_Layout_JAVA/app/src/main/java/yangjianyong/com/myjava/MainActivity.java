package yangjianyong.com.myjava;

import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Gravity;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

//直接用java代码来创建布局文件，并生成几个按钮，不需要Layout中的activity_main文件
//使用线性布局，放置几个按钮
public class MainActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //1-因为没有Layout中的布局文件，所以下面这个语句是无效的，注释掉
        //setContentView(R.layout.activity_main);

        //2-创建一个线性布局
        LinearLayout linearLayout=new LinearLayout(this);
        //3-设置线性布局的参数
        LinearLayout.LayoutParams linearParams=new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
        );
        linearLayout.setOrientation(LinearLayout.VERTICAL);
        linearParams.gravity= Gravity.CENTER_VERTICAL;
        linearLayout.setLayoutParams(linearParams);
        super.setContentView(linearLayout);


        //4-生成文本
        //4-1：创建一个文本组件对象
        TextView textview=new TextView(this);
        //4-2：设置文本的显示信息
        textview.setText("这是用java生成的文本信息");
        //4-3：设置文本的显示颜色和尺寸
        textview.setTextColor(Color.RED);
        textview.setTextSize(24);

        //4-4:设置文本的参数
        LinearLayout.LayoutParams params=new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
        );
        //4-5：设置对其方式
        params.gravity=Gravity.CENTER;
        //4-6:将设置好的参数加载到文本组件上
        textview.setLayoutParams(params);
        //4-7:将文本组件加载到布局中
        linearLayout.addView(textview);


        //5:创建几个按钮并放到布局文件中
        for(int i=0;i<4;i++){
            //5-1：生成组件
            Button bnt=new Button(this);
            //5-2：设置组件的信息
            bnt.setText("这是一个用java生成的按钮");
            bnt.setBackgroundColor(Color.GREEN);
            bnt.setTextColor(Color.WHITE);
            bnt.setTextSize(16);
            LinearLayout.LayoutParams bntparams=new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
            );
            bntparams.gravity=Gravity.CENTER;
            bnt.setLayoutParams(bntparams);

            //5-3:将组件放置到布局文件中
            linearLayout.addView(bnt);
        }
    }
}
