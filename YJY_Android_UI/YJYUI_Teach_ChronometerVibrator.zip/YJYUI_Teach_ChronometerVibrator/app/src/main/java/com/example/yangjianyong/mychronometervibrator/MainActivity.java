package com.example.yangjianyong.mychronometervibrator;

import android.app.Activity;
import android.app.Service;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.SystemClock;
import android.os.Vibrator;
import android.view.View;
import android.widget.Button;
import android.widget.Chronometer;

import java.io.IOException;

public class MainActivity extends Activity {

    private Chronometer myChronometer = null ;
    private Button butStart = null ;
    private Button butStop = null ;
    private Button butBase = null ;
    private Button butFormat = null ;
    private Vibrator vibrator =null;
    private AudioManager audiomanager=null;
    private MediaPlayer mplayer=null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        this.myChronometer = (Chronometer) super.findViewById(R.id.myChronometer) ;
        this.butStart = (Button) super.findViewById(R.id.butStart) ;
        this.butStop = (Button) super.findViewById(R.id.butStop) ;
        this.butBase = (Button) super.findViewById(R.id.butBase) ;
        this.butFormat = (Button) super.findViewById(R.id.butFormat) ;
        this.butStart.setOnClickListener(new OnClickListenerImplStart()) ;
        this.butStop.setOnClickListener(new OnClickListenerImplStop()) ;
        this.butBase.setOnClickListener(new OnClickListenerImplBase()) ;
        this.butFormat.setOnClickListener(new OnClickListenerImplFormat()) ;
        this.vibrator=(Vibrator)super.getApplication().getSystemService(Service.VIBRATOR_SERVICE);
        this.audiomanager=(AudioManager)super.getSystemService(Service.AUDIO_SERVICE);
    }

    private class OnClickListenerImplStart implements View.OnClickListener {
        @Override
        public void onClick(View v) {
            MainActivity.this.myChronometer.start() ;	// 开始计时
        }

    }
    private class OnClickListenerImplStop implements View.OnClickListener {
        @Override
        public void onClick(View v) {
            MainActivity.this.myChronometer.stop() ;	// 停止计时
            MainActivity.this.vibrator.vibrate(3000);
            Uri alert = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);

            mplayer= MediaPlayer.create(MainActivity.this,alert);
            MainActivity.this.audiomanager.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_RAISE, AudioManager.FLAG_SHOW_UI);
            mplayer.setLooping(true);
            try {
                mplayer.prepare();
            } catch (IllegalStateException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            } catch (IOException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
            mplayer.start();
        }

    }
    private class OnClickListenerImplBase implements View.OnClickListener {
        @Override
        public void onClick(View v) {
            MainActivity.this.myChronometer.setBase(SystemClock
                    .elapsedRealtime());	 				// 复位
            MainActivity.this.vibrator.cancel();
            MainActivity.this.audiomanager.setStreamMute(AudioManager.STREAM_MUSIC,true);
            mplayer.stop();
        }

    }
    private class OnClickListenerImplFormat implements View.OnClickListener {
        @Override
        public void onClick(View v) {
            MainActivity.this.myChronometer.setFormat("新的显示格式：%s。") ;
        }

    }

}
