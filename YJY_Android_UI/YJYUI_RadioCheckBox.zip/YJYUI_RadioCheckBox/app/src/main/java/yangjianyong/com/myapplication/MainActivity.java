package yangjianyong.com.myapplication;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

//准备工作1：在res-layout-activity_main中设计布局文件，使用表格布局来实现


public class MainActivity extends Activity {
    //步骤1：声明程序中用到的控件
    private RadioGroup rgsex,rgidentity;
    private CheckBox checkbox1,checkbox2,checkbox3,checkbox4,checkbox5,checkbox6;
    private Button bntsubmit=null;

    //步骤6：设置存放信息的字符串数组
    private  String[]  str=new String[5];

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //步骤2：找到那些控件
        rgsex=findViewById(R.id.radioGroupSex);
        rgidentity=findViewById(R.id.radioGroupIdentity);
        checkbox1=findViewById(R.id.like1);
        checkbox2=findViewById(R.id.like2);
        checkbox3=findViewById(R.id.like3);
        checkbox4=findViewById(R.id.like4);
        checkbox5=findViewById(R.id.like5);
        checkbox6=findViewById(R.id.like6);
        //步骤3：找到那个按钮
        bntsubmit=findViewById(R.id.bntsubmit);

        //步骤4：设置按钮的事件监听，捕获用户的点击信息，转到步骤5
        bntsubmit.setOnClickListener(new OnClickListenerImpl());
    }

    //步骤5：设置一个string【】，来存放设置的信息,回到步骤6
    private class OnClickListenerImpl implements  View.OnClickListener{
        @Override
        public void onClick(View view) {
            int k=0;
            str[k]="您的选择是:";
            String strshow="";
            //步骤7：获得单选按钮组的信息
            for (int i=0;i<rgsex.getChildCount();i++){
                RadioButton rbsex= (RadioButton) rgsex.getChildAt(i);
                if (rbsex.isChecked()){
                    str[++k]="您的性别是:"+rbsex.getText().toString();
                    break;
                }
            }

            for (int i=0;i<rgidentity.getChildCount();i++){
                RadioButton rbsex= (RadioButton) rgidentity.getChildAt(i);
                if (rbsex.isChecked()){
                    str[++k]="您的身份是:"+rbsex.getText().toString();
                    break;
                }
            }

            //步骤8：
            str[++k]="您的爱好是:";
            if (checkbox1.isChecked()) str[k]+=checkbox1.getText().toString()+"  ";
            if (checkbox2.isChecked()) str[k]+=checkbox2.getText().toString()+"  ";
            if (checkbox3.isChecked()) str[k]+=checkbox3.getText().toString()+"  ";
            str[++k]="您的参加的社团是:";
            if (checkbox4.isChecked()) str[k]+=checkbox4.getText().toString()+"  ";
            if (checkbox5.isChecked()) str[k]+=checkbox5.getText().toString()+"  ";
            if (checkbox6.isChecked()) str[k]+=checkbox6.getText().toString()+"  ";

            for (k=0;k<str.length;k++){
                strshow+=str[k]+"\r\n";
            }
            Toast.makeText(MainActivity.this,strshow,Toast.LENGTH_LONG).show();

        }
    }


}
