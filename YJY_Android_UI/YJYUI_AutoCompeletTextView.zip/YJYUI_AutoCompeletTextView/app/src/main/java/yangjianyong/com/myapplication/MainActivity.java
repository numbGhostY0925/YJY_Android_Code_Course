package yangjianyong.com.myapplication;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;

//准备工作1：首先在res-layout中设计布局文件，放置一个线性布局和一个自动完成文本框
//在文本框中重要的是设置阈值为2
//准备工作2：编写一个字符串数组，res-values-自定义一个xml文件

public class MainActivity extends Activity {
    //步骤1：声明程序中需要用到的那个控件
    private AutoCompleteTextView autoCompleteTextView=null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //步骤2：在布局文件中找到控件
        autoCompleteTextView=findViewById(R.id.autotext);

        //步骤3：在资源文件中找到设计好的字符串数组
        String[]   stringxml=super.getResources().getStringArray(R.array.xmlarraystring);
        //步骤4：将字符串数值装配到arrayAdapter中
        ArrayAdapter<String> adapter=new ArrayAdapter<String>(this,
                android.R.layout.simple_dropdown_item_1line,
                stringxml);
        //步骤5：将arrayAdapter加载到控件上
        autoCompleteTextView.setAdapter(adapter);
    }
}
