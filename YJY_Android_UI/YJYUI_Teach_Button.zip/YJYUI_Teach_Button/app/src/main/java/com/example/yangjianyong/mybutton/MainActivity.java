package com.example.yangjianyong.mybutton;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button login=(Button)findViewById(R.id.login);		//通过ID获取布局文件中添加的按钮
        Button bntregister=(Button)findViewById(R.id.register);
        login.setOnClickListener(new View.OnClickListener() {	//为按钮添加单击事件监听
            @Override
            public void onClick(View v) {
                Toast toast=Toast.makeText(MainActivity.this, "您单击了“登录”按钮", Toast.LENGTH_SHORT);
                toast.show();
            }
        });
        bntregister.setOnClickListener(new OnClickListenerImpl());
    }

    private class OnClickListenerImpl implements View.OnClickListener {
        @Override
        public void onClick(View v) {
            // TODO Auto-generated method stub
            Toast toast=Toast.makeText(MainActivity.this, "您单击了“注册”按钮", Toast.LENGTH_SHORT);
            toast.show();
        }
    }

    public  void myClick (View view) {
        Toast toast=Toast.makeText(MainActivity.this, "您单击了“重置”按钮", Toast.LENGTH_SHORT);
        toast.show();
    }
}
