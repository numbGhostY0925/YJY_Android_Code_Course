package com.example.yangjianyong.myratingbar;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.RatingBar;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private RatingBar ratingbar;	//星级评分条
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ratingbar = (RatingBar) findViewById(R.id.ratingBar1);	//获取星级评分条

        ratingbar.setOnRatingBarChangeListener(new RatingBar.OnRatingBarChangeListener() {

            @Override
            public void onRatingChanged(RatingBar ratingBar, float rating,
                                        boolean fromUser) {
                String toaststr="自行改变"+"\r\n";
                if (fromUser==true){
                    toaststr="用户触摸改变"+"\r\n";
                }
                toaststr +="你改变到"+rating+"颗星";
                Toast.makeText(MainActivity.this, toaststr, Toast.LENGTH_SHORT).show();
            }
        });

        Button bntchange=(Button)findViewById(R.id.button2);
        bntchange.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                int result=ratingbar.getProgress();	//获取进度
                float step=ratingbar.getStepSize();	//获取每次最少要改变多少个星级
                float rating=ratingbar.getRating();	//获取等级
                result+=step;
                rating+=step;
                ratingbar.setProgress(result);
                ratingbar.setRating(rating);
            }
        });



        Button button=(Button)findViewById(R.id.button1);		//获取提交按钮
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int result=ratingbar.getProgress();	//获取进度
                float rating=ratingbar.getRating();	//获取等级
                float step=ratingbar.getStepSize();	//获取每次最少要改变多少个星级
                Log.i("星级评分条","step="+step+" result="+result+" rating="+rating);
                Toast.makeText(MainActivity.this, "你得到了"+rating+"颗星", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
